var TO_TAG =[]
var TAGGED_ITEMS = {}
var TAGGERS =[]
var SESSION_QST

var count = 0
$(document).ready(function() {
	keys =['a', 'l','g', 'e', 'o', 'n']
	loadItems();
	current = 0
	if (TO_TAG[0]) {
		loadToTag(current)	
	}
	
	$(document).on('keypress',function (event){

		key = String.fromCharCode(event.keyCode)
		if (!(TO_TAG[0])) {
			return;
		} 
  		else if (keys.indexOf(key) == -1) {
  			return;
  		}
  		else {appendPrevious(key, $('#tag_item')[0].dataset.sent_pos)}

  		current+=1
  		$('#tag_item').remove()
  		loadToTag(current)

	});

	$(document).on('click', "#tagged_row td.edit-tag", function(event) {
		$('#tag_item').remove()
		current-=1
		var to_edit = $(this).parent()[0].dataset.id
		$(this).parent().remove()
		loadToTag(to_edit)
	});

});

function loadItems() {
	var temp
	var url = '/load_data'

	$.ajax({
		url: url,
		async: false,
		type: "GET"
	}).success(function (data) {
		var new_data = jQuery.parseJSON(data);
		if (new_data.sents) {
			TO_TAG = new_data.sents
		}
		else if (data.error){
			$('#error-msg').html(data.error).style('background', 'aliceblue')
		}
		else {
			document.location.href = data
		}
	});			
}

function loadToTag(num) {
	// $('#record')[0].innerText = TO_TAG[num]

	$('#record').append('<tr id="tag_item" data-sent_pos="' + num + '"><td>' + TO_TAG[num] +'</td></tr>')

}

function appendPrevious(key, sent_pos) {
	var response;
	if (key=='a') { response = 'AUTHORITY'}
	else if (key=='l') { response = 'ANALOGY'}
	else if (key=='g') { response = 'GENERALIZATION'}
	else if (key=='e') { response = 'EXPERIENCE'}
	else if (key=='o') { response = 'OTHER'}
	else { response = 'NO JUSTIFICATION'}
	$('#previous-table').prepend('<tr id="tagged_row" data-id="' + sent_pos +  '"><td class ="edit-tag">' 
		+ TO_TAG[sent_pos] +'</td><td class ="edit-tag">' + response+ '</td></tr>');
	TAGGED_ITEMS[sent_pos] = response
	count++;
	$('#counter').text(count);
}

function saveLabels() {
	if (count < 1) {
		$('#error-msg').html('You have not tagged any data!').style('background', 'aliceblue')
		return;
	}

	var saveItems = {'toSave' : JSON.stringify({'tags': TAGGED_ITEMS})}
	console.log(saveItems)
	$.ajax({
		url: '/savelabels',
		type: 'POST',
		data: saveItems
	}).success(function (data) {
		document.location.href = data
		// console.log(data)
	});
}

