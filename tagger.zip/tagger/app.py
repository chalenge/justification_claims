'''
Created on Dec 02, 2014
@author: chalenge
'''
import random
import json
import cPickle as pickle

from flask import Flask, request, render_template, jsonify, redirect, url_for


''' ------------------------------- setup and initialize app ------------------------------- '''
app = Flask(__name__)

''' ---------------------------------------- Routes ---------------------------------------- '''
@app.route('/')
def index():
    return render_template('tagSession.html')

@app.route('/load_data', methods=['GET'])
def load_session_data():
    global to_ml
    try:        
        with open('../tagger/new_to_tag.json', 'rb') as fp:
            to_ml = eval(fp.read())

        sentences = []
        # to_ml = eval(to_ml)
        for sent in to_ml:
            sentences.append(sent['untagged'])

        sentences = json.dumps({'sents': sentences}, ensure_ascii=False)
        return sentences
    
    except Exception as error_detail:
        return jsonify({'error': 'Error ({0})'.format(error_detail)})
                # return jsonify({'a': a})

@app.route('/savelabels', methods=['GET','POST'])
def saveLabels():
    
    ''' Code to post tagged data to PostGresDBase  and update tag list and remove those tagged in RedisDBase'''
    
    # Use try to handle excpetions
    try:
    #Get the string object passed from the form where data was tagged
        tagdataString = request.form['toSave']

        #Convert the data into a json object
        tagdata = json.loads(tagdataString)
        tags = tagdata['tags']
        tagged_sents = []
        keys = []
        for key in tags:
            to_ml[int(key)]['justification'] = tags[key]
            tagged_sents.append(to_ml[int(key)])
            keys.append(int(key))

        last_tag = max(keys)        
        #Save and append tags to file
        with open('justification_tags.json', 'r+b') as tags_file:
            stored = eval(tags_file.read())            
            to_save = stored + tagged_sents

            tags_file.seek(0)
            json.dump(to_save, tags_file, ensure_ascii=False)
        
        with open('new_to_tag.json', 'wb') as sents_file:
            json.dump(to_ml[last_tag+1:], sents_file, ensure_ascii=False)

        return url_for('index')
    
    except Exception as error_detail:
        return jsonify({'error': 'Error ({0})'.format(error_detail)})

''' --------------------------------- Main Function -------------------------------------- '''                  
if __name__ == '__main__':
    app.run(host='0.0.0.0',
         port=int('50001'), debug = True)